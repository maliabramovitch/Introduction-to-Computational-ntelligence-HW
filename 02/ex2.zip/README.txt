Malka Abramovitch 314723586
Maor Betser 315841445

Files:
- calcTSP.py- the python code that can be run
- MyGA.py- our implementation of GA
- 02.ipynb- Jupiter notebook with the code running results- recommended for checking it holds all the running data.
- Optimizing TSP with GA.docx- summary log
