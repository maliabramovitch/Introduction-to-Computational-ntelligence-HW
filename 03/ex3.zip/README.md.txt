Malka Abramovitch 314723586
Maor Betser 315841445

Files:
    - Ofer Shir's files:
        - ellipsoidFunctions.py
        - MixedVariableObjectiveFunctions.py
    - 1p1_ES_with_ObjectiveFunctionClass.py- the python code that can be run
    - Jupiter notebooks with the code running results - recommended for checking it holds all the running data.
        - 030.ipynb- results for 30 runs for each function (good results but not 'the' best for genHadamardHellipse)
        - 1p1_ES_with_ObjectiveFunctionClass.ipynb- results with the best value for the 3rd function (genHadamardHellipse)
    - summary.docx- summary log