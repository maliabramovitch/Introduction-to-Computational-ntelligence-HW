Malka Abramovitch 314723586
Maor Betser 315841445

Files:
    - Ofer Shir's files:
        - ellipsoidFunctions.py
        - MixedVariableObjectiveFunctions.py
    - 1p1_ES_with_ObjectiveFunctionClass.py- the python code that can be run
    - Jupiter notebooks with the code running results - recommended for checking it holds all the running data.
        - 030.ipynb- no good plots but good results.
        - 031.ipynb- plot without y-axis bounders so it doesn't look as good as below plots
        - 032.ipynb
        - 033.ipynb
        - 034.ipynb
    - summary.docx- summary log