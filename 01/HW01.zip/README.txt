Malka Abramovitch
314723586

Files:
- HW01.py- the python code that can be run
- HW01-solution notebook.ipynb- Jupiter notebook with the code running results- recommended for checking it holds all the running data.
- summery.docx- summery log
- summery.pdf- summery log in pdf
