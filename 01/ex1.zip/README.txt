Malka Abramovitch
314723586

Files:
- HW01.py- the python code that can be run
- HW01.ipynb- Jupiter notebook with the code running results.
- summery.docx- summery log

